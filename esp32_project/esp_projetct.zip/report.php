<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Information to Machine</title>
    <style>
        .daily-close {
            background-color: #ffcccb;
            font-weight: bold;
        }
    </style>
</head>
<body>
<header>
    <nav>
        <div class="navbar">
            <div class="item">
                <h1 id="machine_name">Machine</h1>
            </div>
        </div>
    </nav>
</header>
<main>
    <div class="container">
        <table id="report_table">
            <thead>
                <tr>
                    <th>Date and Time</th>
                    <th>PESOS</th>
                    <th>COIN</th>
                    <th>PREMIOS</th>
                    <th>BANCO</th>
                </tr>
            </thead>
            <tbody>
                <!-- Data will be inserted here -->
            </tbody>
        </table>
    </div>
</main>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Obtener el deviceId de la URL para mostrar el nombre de la máquina
    const urlParams = new URLSearchParams(window.location.search);
    const deviceId = urlParams.get('device_id');
    const machineName = document.getElementById('machine_name');
    machineName.innerText = `Machine ${deviceId}`;

    // Realizar una solicitud para obtener los reportes y cierres diarios
    fetch(`/esp32_project/get_report.php?device_id=${deviceId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Convertir la respuesta en JSON
        })
        .then(data => {
            if (data.error) {
                console.error(data.error);
            } else {
                const reports = data.reports || [];
                const closes = data.closes || [];
                const tableBody = document.querySelector("#report_table tbody");
                tableBody.innerHTML = ""; // Limpiar la tabla antes de insertar nuevos datos

                // Combinar los reportes y cierres diarios en una sola lista
                const combinedData = [];

                // Convertir los cierres diarios y reportes a objetos con una propiedad 'date' para facilitar la comparación
                reports.forEach(report => {
                    combinedData.push({
                        type: 'report',
                        date: new Date(report.timestamp),
                        data: report
                    });
                });

                closes.forEach(close => {
                    combinedData.push({
                        type: 'close',
                        date: new Date(close),
                    });
                });

                // Ordenar los datos combinados por fecha en orden descendente (más reciente primero)
                combinedData.sort((a, b) => b.date - a.date);

                // Insertar los datos ordenados en la tabla
                combinedData.forEach(item => {
                    if (item.type === 'report') {
                        // Crear una fila para el reporte
                        const reportRow = document.createElement("tr");
                        reportRow.innerHTML = `
                            <td>${item.date.toLocaleString()}</td>
                            <td>${item.data.dato1}</td>
                            <td>${item.data.dato2}</td>
                            <td>${item.data.dato3}</td>
                            <td>${item.data.dato4}</td>
                        `;
                        tableBody.appendChild(reportRow); // Insertar el reporte en la tabla
                    } else if (item.type === 'close') {
                        // Crear una fila para el cierre diario
                        const closeRow = document.createElement("tr");
                        closeRow.classList.add("daily-close");
                        closeRow.innerHTML = `
                            <td colspan="6">Cierre Diario: ${item.date.toLocaleDateString()}</td>
                        `;
                        tableBody.appendChild(closeRow); // Insertar el cierre diario en la tabla
                    }
                });
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
});

</script>
</body>
</html>
